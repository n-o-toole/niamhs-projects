This Folder contains the Housekeeping.py file used on board the RadSat TupperSat mission. The file works using the following logic:

A Setup class is defined to initialise the DS18B20, MCP3008, LEA-G6 and Pico for use in the system files.
The Setup class defines the pins that the sensors are found on and stores them as variables to be called later.

A temperature() function takes the sensors and roms variables for the temperature sensors from the Setup class and tells the sensors
to take a measurement by defining the internal and external temperature sensors, then returns the values as variables

An unpack buffer function is created to unpack the bytearray provided from the MCP3008 pressure sensor for use in calibration

The calibration function unpacks the calibration coefficients of the MCP3008 sensor and returns them as a list to be called in the compute_pressure() function

The read_adc() function reads the ADC values of the pressure from the MCP3008 sensor and returns the value as a variable after unpacking

The read_pressure() function uses the calibration constants and ADC pressure values and converts to millibars

A ddmm_to_decimal function takes a ddmm string from the GPS and converts it to decimal degrees

A to_signed_angle() function takes the decimal degrees and converts it to a signed angle based on location in cardinal coordinates

A parse_nmea() function takes an NMEA string from the GPS and exports a dictionary with latitude, longitude, altitude, timestamp, NMEA sentence,
a checksum field and s horizontal degrees of precision value as a dictionary while storing all sentence types found

A listen_for_GGA() function checks the port to listen for GGA sentences specifically on a loop to return only GGA sentences for GPS measurements

A housekeeping() function is implemented to read all the values of the HK sensors and return them as variables.

