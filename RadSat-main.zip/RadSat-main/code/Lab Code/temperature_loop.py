import machine 
import time
import onewire
import ds18x20

#setup the sensors as in temperature.py
sensor_1 = machine.Pin(15)
sensor_2 = machine.Pin(11)

temperature_sensors_1 = ds18x20.DS18X20(onewire.OneWire(sensor_1))
temperature_sensors_2 = ds18x20.DS18X20(onewire.OneWire(sensor_2))

roms_1 = temperature_sensors_1.scan()
roms_2 = temperature_sensors_2.scan()
print ( ' Found DS devices : ' , roms_1, ", ", roms2)

def temperature_loop(time):
    """
    A function that loops for a certain time period and provides temperature data
    -----------------------------------------------------------------------------
    input: time for function to loop (s) (int)
    -----------------------------------------------------------------------------
    output: Print statement for time (s) (float) and temperature (C) (float)
    """
    temperature_sensors_1.convert_temp()
    temperature_sensors_2.convert_temp()
    
    #take timestamp and run loop until 'time' seconds have passed
    timestamp = time.time()
    while time.time() < timestamp+time:
        time.sleep_ms(5000) #arbitrary wait period between scans
        temperature_sensors_1.convert_temp()
        temperature_sensors_2.convert_temp()

        tempC_1 = temperature_sensors_1.read_temp(roms_1[0])
        tempC_2 = temperature_sensors_2.read_temp(roms_2[0])
        
        if tempC_1 > 0:
            sign_1 = '+'
        else:
            sign_1 = '-'
        if tempC_2 > 0:
            sign_2 = '+'
        else:
            sign_2 = '-'
        
        print(f'Time: {time.time():.6f}, Temperature 1 (C): {sign_1}{tempC_1:.2f}, Temperature 2 (C): {sign_2}{tempC_2:.2f}')




