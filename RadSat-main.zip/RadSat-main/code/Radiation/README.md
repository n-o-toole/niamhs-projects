Folder for files used in the radiation detector script development
