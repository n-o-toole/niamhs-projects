Any extra files used in the project are kept here. These files are gps_airborne.py and sdcard.py for establishing airborne
mode on the GPS and connection to the on board SD card.
