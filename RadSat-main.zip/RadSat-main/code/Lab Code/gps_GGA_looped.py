from machine import UART, Pin
import time


result = {
    'longitude': [],
    'latitude': [],
    'altitude': [],
    'timestamp': [],
    'sentence': [],
    'checksum': [],
    'fields': {}
    }

def ddmm_to_decimal(ddmm_str):
    """Convert DDMM.MMMMMM or DDDMM.MMMMMM format to decimal degrees."""
    if not ddmm_str or ddmm_str == '':
        return None
    
    ddmm = float(ddmm_str)
    degrees = int(ddmm / 100)
    minutes = ddmm - (degrees * 100)
    decimal_degrees = degrees + (minutes / 60.0)
    
    return decimal_degrees


def to_signed_angle(decimal_degrees, direction):
    """Convert to signed angle based on direction (N/S/E/W)."""
    if decimal_degrees is None or not direction:
        return None
    
    if direction in ['S', 'W']:
        return -decimal_degrees
    else:
        return decimal_degrees

def parse_nmea(sentence):
    """Parse NMEA sentence and extract latitude, longitude, altitude, timestamp."""
    
    sentence = sentence.strip()
    
    if '*' in sentence:
        sentence_part, checksum = sentence.split('*')
        result['checksum'].append(checksum)
    else:
        sentence_part = sentence
    
    parts = sentence_part.split(',')
    sentence_type = parts[0][1:]  
    fields = parts[1:]
    
    result['fields'] = {
        'sentence_type': sentence_type,
        'data': fields
    }
    
    if 'GGA' in sentence_type:
        result['sentence'].append(sentence)
        if len(fields) >= 9 and fields[1]:
            if fields[0]:
                time_str = fields[0]
                if time_str == "":
                    result['timestamp'].append("N/A")
                else:
                    result['timestamp'] = f"{time_str[0:2]}:{time_str[2:4]}:{time_str[4:6]}"
            
            result['latitude'].append(to_signed_angle(ddmm_to_decimal(fields[1]), fields[2]))
            result['longitude'].append(to_signed_angle(ddmm_to_decimal(fields[3]), fields[4]))
            
                                        
            
            if fields[8]:
                result['altitude'].append(float(fields[8]))
    
    return result

def listen_for_sentence(port, sentence_type):
    """Listen for NMEA sentence_type on GPS serial port."""
    while True:
        if port.any():
            try:
                sentence = port.readline().decode('ascii').strip()

                if len(sentence) >= 6 and sentence[3:6] == sentence_type:
                    return sentence
            except ValueError as e:
                print(f"Value Error: {e}")
            except Exception as e:
                print(f"Exception found: {e}")
        else:
            time.sleep(1)

def main():
    time_now = time.time()
    """Read GPS data and parse it continuously."""
    uart = UART(1, baudrate=9600, tx=Pin(4), rx=Pin(5))
    uart.init(9600, bits=8, parity=None, stop=1)
    time.sleep(1)
    
    while True:
    
        sentence = listen_for_sentence(uart, 'GGA')
        data = parse_nmea(sentence)
        print(f"Raw sentence: {data['sentence'][-1]}")
        print(f"Latitude:  {data['latitude']} Degrees")
        print(f"Longitude: {data['longitude']} Degrees")
        print(f"Altitude:  {data['altitude']} Meters")
        print(f"Timestamp: {data['timestamp']} HH:MM:SS")
        print(f"Checksum:  {data['checksum'][-1]}")
        print()
        if time.time() > time_now + 60:
            break
        else:
            time.sleep(2)
    print(data['checksum'])
main()
