#import _rhserial_radio


# standard library imports
import time

# uPython imports
from machine import UART, Pin

# tuppersat imports
from tuppersat.radio import TupperSatRadio


import machine , onewire , ds18x20



# constants
UART_ID = 0
TX_PIN = 16
RX_PIN = 17
T3_BAUDRATE = 38400

ADDRESS = 0xfe
CALLSIGN = 'MIKUSAT1'

i2c = machine.I2C(0,scl = machine.Pin(13),sda = machine.Pin(12))
sensor_1 = machine.Pin(15)

temperature_sensors_1 = ds18x20.DS18X20(onewire.OneWire(sensor_1))

devices = i2c.scan()
roms_1 = temperature_sensors_1.scan()
print ( ' Found DS devices : ' , roms_1,devices)
temperature_sensors_1.convert_temp()
tempC_1 = temperature_sensors_1.read_temp(roms_1[0])



def unpack(buffer):
    _buffer = reversed(bytearray(buffer))
    return sum(_byte << (_i * 8) for _i, _byte in enumerate(_buffer))



i2c.writeto(119, bytes(2))
c1bytes = i2c.readfrom_mem(119, 0xA2, 2)
c2bytes = i2c.readfrom_mem(119, 0xA4, 2)
c3bytes = i2c.readfrom_mem(119, 0xA6, 2)
c4bytes = i2c.readfrom_mem(119, 0xA8, 2)
c5bytes = i2c.readfrom_mem(119, 0xAA, 2)
c6bytes = i2c.readfrom_mem(119, 0xAC, 2)


c1 = unpack(c1bytes)
c2 = unpack(c2bytes)
c3 = unpack(c3bytes)
c4 = unpack(c4bytes)
c5 = unpack(c5bytes)
c6 = unpack(c6bytes)
#print(c1,c2,c3,c4,c5,c6)

c = []
c.append(None)
c.append(c1)
c.append(c2)
c.append(c3)
c.append(c4)
c.append(c5)
c.append(c6)

def pressure():
    temp_adc = b'\x48'
    i2c.writeto(119, temp_adc)
    time.sleep_ms(50)

    t_adc_bytes = i2c.readfrom_mem(119, 0x00, 3)
    t_adc = unpack(t_adc_bytes)


    pressure_adc = b'\x58'
    i2c.writeto(119, pressure_adc)
    time.sleep_ms(50)

    p_adc_bytes = i2c.readfrom_mem(119, 0x00, 3)
    p_adc = unpack(p_adc_bytes)

    dt = t_adc - (c5*(2**8))
    temperature = 2000+dt*(c6/(2**23))
    temperature /= 100

    off_p = (c2*(2**16)) + (c4 * dt)/2**7
    sens = (c1*(2**15)) + (c3*dt)/2**8
    pres = (t_adc*sens/2**21-off_p)/2**15
    pres /= 100
    return temperature, pres

def loop(radio, pause=1):
    # send a blank telemetry packet.
    print('Sending telemetry')
    
    temperature_sensors_1.convert_temp()
    tempC_1 = temperature_sensors_1.read_temp(roms_1[0]) 
    temp, pres = pressure()
    radio.send_telemetry(
        hhmmss     = None,
        latitude   = 1,
        longitude  = None,
        hdop       = None,
        altitude   = None,
        t_internal = tempC_1,
        t_external = temp,
        pressure   = pres,
    )
    time.sleep(pause)

def main():
    uart = UART(UART_ID, baudrate=T3_BAUDRATE, tx=Pin(TX_PIN), rx=Pin(RX_PIN))
    radio = TupperSatRadio(uart, ADDRESS, CALLSIGN)
    
    time_now = time.time()
    while True:

        
        
        
        loop(radio)
        
        if time.time() > time_now + 60:
            break
        else:
            time.sleep(2)
            
main()