import machine, time
i2c = machine.I2C(0,scl = machine.Pin(13),sda = machine.Pin(12))
devices = i2c.scan()
print(devices)


addrs = [0xA2, 0xA4, 0xA6, 0xA8, 0xAA, 0xAC]

def unpack(buffer):
    _buffer = reversed(bytearray(buffer))
    return sum(_byte << (_i * 8) for _i, _byte in enumerate(_buffer))


def read_calibration_constants(bus=119, addr=addrs):
    i2c.writeto(bus, bytes(2))
    c1bytes = i2c.readfrom_mem(bus, addr[0], 2)
    c2bytes = i2c.readfrom_mem(bus, addr[1], 2)
    c3bytes = i2c.readfrom_mem(bus, addr[2], 2)
    c4bytes = i2c.readfrom_mem(bus, addr[3], 2)
    c5bytes = i2c.readfrom_mem(bus, addr[4], 2)
    c6bytes = i2c.readfrom_mem(bus, addr[5], 2)


    c1 = unpack(c1bytes)
    c2 = unpack(c2bytes)
    c3 = unpack(c3bytes)
    c4 = unpack(c4bytes)
    c5 = unpack(c5bytes)
    c6 = unpack(c6bytes)
    #print(c1,c2,c3,c4,c5,c6)

    c = []
    c.append(None)
    c.append(c1)
    c.append(c2)
    c.append(c3)
    c.append(c4)
    c.append(c5)
    c.append(c6)
    return c

def read_adc(bus=119, addr=0x00, cmd=3):
    time.sleep_ms(1000)
    temp_adc = b'\x48'
    i2c.writeto(bus, temp_adc)
    time.sleep_ms(50)

    t_adc_bytes = i2c.readfrom_mem(bus, addr, cmd)
    t_adc = unpack(t_adc_bytes)


    pressure_adc = b'\x58'
    i2c.writeto(bus, pressure_adc)
    time.sleep_ms(50)

    p_adc_bytes = i2c.readfrom_mem(bus, addr, cmd)
    p_adc = unpack(p_adc_bytes)
    return t_adc,p_adc

def compute_pressure(t_adc, p_adc,c=c):
    c1 = c[1]
    c2 = c[2]
    c3 = c[3]
    c4 = c[4]
    c5 = c[5]
    c6 = c[6]
    
    dt = t_adc - (c5*(2**8))
    temperature = 2000+dt*(c6/(2**23))
    temperature /= 100

    off_p = (c2*(2**16)) + (c4 * dt)/2**7
    sens = (c1*(2**15)) + (c3*dt)/2**8
    pres = (t_adc*sens/2**21-off_p)/2**15
    pres /= 100
    
    return temperature, pres

def read_pressure(bus=119, addr=0x00, cmd=3):
    t_adc, p_adc = read_adc(bus, addr, cmd)
    temp, pres = compute_pressure(t_adc, p_adc, c)
    return temp, pres

def pressure_loop(time):
    c = read_calibration_constants(bus, addr)
    timestamp = time.time()
    while time.time() < timestamp + time:
        temp, pres = read_pressure()
        print(f'Timestamp: {time.time()}, Temperature (C): {temp:.2f}, Pressure (mbar): {pres:.2f}')
        time.sleep(2)