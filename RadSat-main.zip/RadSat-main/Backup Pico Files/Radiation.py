from machine import Pin, ADC
import random
import time
import _thread
import sdcard
import uos



# Assign chip select (CS) pin (and start it high)

# Intialize SPI peripheral (start with 1 MHz)
# Initialize SD card


# Mount filesystem

class Radiation:
    def __init__(self):
        global adc_val_list
        self.adc_val_list = []
        self.rad_counter = 0
        self.total_counts = 0
        self.adc_val = 0
        self.trigger_pin = Pin(22, Pin.IN, Pin.PULL_DOWN)
        self.adc_pin = Pin(26, Pin.IN)
        self.adc = ADC(self.adc_pin)
        self.time_init = time.time()
        """
        self.cs = Pin(9, machine.Pin.OUT)
        self.spi = machine.SPI(1,
                  baudrate=1000000,
                  polarity=0,
                  phase=0,
                  bits=8,
                  firstbit=machine.SPI.MSB,
                  sck=machine.Pin(10),
                  mosi=machine.Pin(11),
                  miso=machine.Pin(8))
        
        try:
            self.sd = sdcard.SDCard(spi, cs)
        except Exception as e:
            print(f"Error mounting SD: {e}")
        
        self.vfs = uos.VfsFat(self.sd)
        uos.mount(self.vfs, "/sd")
        
        try:
            self.file = open('/sd/newguy.csv','w')
            self.file.write(str(time.time()))
            self.file.write(",")
            self.file.write(str(self.adc_val))
            self.file.close()
        except OSError:
            print("SD Error")
        """
    def value_reset(self):
        if time.time() >=  self.time_init + 60:
            try:
                self.file = open('/sd/newguy.csv','a')
                self.file.write(str(time.time()))
                self.file.write(",")
                self.file.write(str(self.adc_val))
                self.file.close()
            except OSError:
                print("SD Error")

            self.adc_val_list = []
            self.rad_counter = 0
            self.time_init = time.time()
            
    def count_detected(self, pin):
        #print(time.time())
        global adc_val
        self.adc_val = self.adc.read_u16()
        #print(time.time())
        self.rad_counter += 1
        self.total_counts += 1
        self.adc_val_list.append((time.time(),self.adc_val))
        print(self.adc_val * 3.3/2**16)
            
                                                                                                                                                                                                                                                            

global radiation
radiation = Radiation()

def time_count():
    global timer
    timer = 0
    t = time.time()
    while time.time() < t + 10:
        timer += 1
        #print(timer)
        time.sleep(1)
    vals = radiation.adc_val_list
    print(vals)
    print(f"{radiation.rad_counter} counts detected this loop")
    print(f"{radiation.total_counts} counts detected")
    #radiation.value_reset()


interrupt = radiation.trigger_pin.irq(trigger = Pin.IRQ_RISING, handler = radiation.count_detected)
_thread.start_new_thread(interrupt, ())

def loop():
    while True:
        time_count()
    
loop()