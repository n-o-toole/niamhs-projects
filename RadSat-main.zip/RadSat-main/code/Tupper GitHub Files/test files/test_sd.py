from machine import UART, Pin, SPI
import machine, onewire, ds18x20, time
from Housekeeping import housekeeping
from comms import comms
from ucollections import namedtuple
from tuppersat.radio import TupperSatRadio
import sdcard
import uos

def init_sd():
    """
    Take the CSV file from fetch_clean_data() and send it to the local SD
    file for storage.
    
    Parameters:
    -----------
    transfer_data: file
        CSV file of clean data
        
    Returns:
    --------
    None
    """
    cs = Pin(9, Pin.OUT)
    spi = SPI(1,
              baudrate=1000000,
              polarity=0,
              phase=0,
              bits=8,
              firstbit=machine.SPI.MSB,
              sck=machine.Pin(10),
              mosi=machine.Pin(11),
              miso=machine.Pin(8))
    
    try:
        sd = sdcard.SDCard(spi, cs)
    except Exception as e:
        print(f"Error mounting SD: {e}")
        
    vfs = uos.VfsFat(sd)
    try:
        uos.umount("/sd")
    except OSError as e:
        print(f"Unmount error: {e}")
    
    try:
        uos.mount(vfs, "/sd")
    except OSError as e:
        print(f"Mount error: {e}")
    
    header = "int_temp, ext_temp, pressure, longitude, latitude, altitude, timestamp, hdop"
    try:
        file = open("/sd/housekeeping.csv", "w")
        file.write(header + "\n")
#         file.write(str(time.time()))
#         file.write(",")
#         for val in data:
#             file.write(val)
#             file.write(",")
#         file.write("\n")
        file.close()
    except OSError:
        print("SD Error")
        
    return

def send_to_sd(data):
    
    try:
        file = open("/sd/housekeeping.csv", "a")
        file.write(str(time.time()))
        file.write(",")
        for val in data:
            file.write(val)
            file.write(",")
        file.write("\n")
        file.close()
    except OSError:
        print("SD Error")        

    return

init_sd()

count = 0

while count < 10:
    hk_data = []
    housekeeping_data, radiation_data, timestamp = comms()
    
    for data in housekeeping_data:
        data_str = str(data)
        hk_data.append(data_str)
        
    send_to_sd(hk_data)
    count += 1
