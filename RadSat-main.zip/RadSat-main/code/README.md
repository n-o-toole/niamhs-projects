The folder contains a set of subfolders that contain scripts for each main sensor and the communication
file. When submitting code, please input the changes made and your initials and commit to a side branch before 
it is pushed to the main branch after review. Files shall follow the naming convention sensor_name_v1.1.py,
with major file changes updating the primary version number, major function changes updating the secondary
version number, and any minor changes updating the smallest version number.
