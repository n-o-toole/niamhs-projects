from machine import Pin, ADC, PWM
import machine
import random
import time
import _thread
import sdcard
import uos



class Radiation:
    """
    Class to initialise sensors and SD card along with variables used in the script
    """
    def __init__(self):
        global adc_val_list
        self.pwm = PWM(Pin(27),freq=1000000)#initialise PWM pin for managing pulse width
        self.pwm.duty_u16(5000)#Set the required pulse width
        
        #Lists for storing count values
        self.adc_val_list = []
        self.time_list = []
        
        #variables for counts per loop, total counts and the adc value
        self.rad_counter = 0
        self.total_counts = 0
        self.adc_val = 0
        
        #establish trigger pin for adc reading
        self.trigger_pin = Pin(22, Pin.IN, Pin.PULL_DOWN)
        self.adc_pin = Pin(26, Pin.IN)
        self.adc = ADC(self.adc_pin)
        
        
        #connect to SD card
        self.cs = Pin(9, machine.Pin.OUT)
        self.spi = machine.SPI(1,
                  baudrate=1000000,
                  polarity=0,
                  phase=0,
                  bits=8,
                  firstbit=machine.SPI.MSB,
                  sck=machine.Pin(10),
                  mosi=machine.Pin(11),
                  miso=machine.Pin(8))
        time.sleep(5)
        
        #try to mount SD card
        try:
            self.sd = sdcard.SDCard(self.spi,self.cs)
        except Exception as e:
            print(f"Error mounting SD: {e}")
        
        try:
            self.vfs = uos.VfsFat(self.sd)
        except AttributeError as e:
            print(f'Error with SD Card - Rad file {e}')
        try:
            uos.umount("/sd")
        except OSError as e:
            print(f"Unmount error: {e}")
        
        try:
            uos.mount(self.vfs, "/sd")
        except OSError as e:
            print(f"Mount error: {e}")
        except AttributeError as e:
            print(f'SD Card Error : {e}')
            
        #define headers for SD card write
        self.header = "Timestamp,ADC Value"
        
        #write headers to SD card
        try:
            self.file = open('/sd/Radiation.csv','a')
            self.file.write(self.header + '\n')
            self.file.close()
        except OSError as e:
            print(f"SD Error - Rad Write, {e}")
        
    def write_sd(self):
        """
        Function called to write radiation data to the SD card
        Data written is the time in nanoseconds a count was detected and the ADC value of the count
        """
        try:
            self.file = open('/sd/Radiation.csv','a')
            for val in range(len(self.adc_val_list)):
                self.file.write(str(self.time_list[val]))
                self.file.write(",")
                self.file.write(str(self.adc_val_list[val])+'\n')
            #self.file.write('Counts this loop:' + '\n')
            #self.file.write([time.time(), self.rad_counter])
            #self.file.write('\n')
            self.file.close()
        except OSError as e:
            print(f"SD Error - Rad Append, {e}")
        
        #Clear the ADC Value and Time list after writing
        self.adc_val_list = [] 
        self.time_list = []
            
    def count_detected(self, pin):
        """
        Function that takes ADC value from pin when triggered
        """
        
        global adc_val
        #get ADC value from pin
        self.adc_val = self.adc.read_u16()
        
        #add count to loop and total counters and append values to list
        self.rad_counter += 1
        self.total_counts += 1
        self.adc_val_list.append(self.adc_val)
        self.time_list.append(time.time_ns())
                                                                                                                                                                                                                                                 

global r
r = Radiation()

#Define a trigger pin interrupt method to trigger when the
#pin gets a rising ADC voltage and run the count detected script
interrupt = r.trigger_pin.irq(trigger = Pin.IRQ_RISING, handler = r.count_detected)

#start a new thread using the interrupt
_thread.start_new_thread(interrupt, ())

def count_fetch():
    """
    Simple function to be called to fetch the total counts and loop counts then write to SD
    """
    r_c = r.rad_counter
    t_c = r.total_counts
    r.write_sd()
    return t_c, r_c

def count_reset():
    #reset the rad counter
    r.rad_counter = 0
    
