from machine import UART, Pin
import machine, onewire, ds18x20, time
from Housekeeping.py import housekeeping

def fetch_raw_data():
    """
    Fetch the output from Housekeeping.py
    
    Parameters:
    -----------
    None
    
    Returns:
    --------
    temp_int: float
    temp_ext: float
    pressure: float
    latitude: float
    longitude: float
    altitude: float
    radiation: float
    """
    #time_now() = time.time()
    
    while True:
        time.sleep(1)
        
        temp_int, temp_ext, pressure, GPS_data = housekeeping()
        
        # extract data
        raw_sentence = GPS_data['sentence'][-1]
        latitude = GPS_data['latitude']
        longitude = GPS_data['longitude']
        altitude = GPS_data['altitude']
        timestamp = GPS_data['timestamp']
        checksum = GPS_data['checksum']
        time.sleep(10)
        #if time.time() > time_now + 10:
            #break
        #else:
            #time.sleep(1)
        
    return temp_int, temp_ext, pressure, longitude, latitude, altitude, timestamp, checksum

def fetch():
    temp_int, temp_ext, pressure, longitude, latitude, altitude, timestamp, checksum = fetch_raw_data()
    
    print(f"Internal Temp: {temp_int:.2f}")
    print(f"External Temp: {temp_ext}")
    print(f"Pressure: {pressure:.2f} millibars")
    print(f"Longitude: {longitude}")
    print(f"Latitude: {latitude}")
    print(f"Altitude: {altitude}")
    print(f"Time: {timestamp}")
    print(f"Checksum: {checksum}")
    
    return

fetch()
