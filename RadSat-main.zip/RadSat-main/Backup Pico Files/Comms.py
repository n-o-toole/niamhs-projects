from machine import UART, Pin
import machine, onewire, ds18x20, time
from Housekeeping import housekeeping
from ucollections import namedtuple
from tuppersat.radio import TupperSatRadio
import Radiation

rad = Radiation.Radiation()

def setup_antenna(pin_nums):
    """
    Initialise the antenna.
    """
    # extract tx and rx pins and define constants
    UART_ID = 0
    TX_PIN = pin_nums[-2]
    RX_PIN = pin_nums[-1]
    T3_BAUDRATE = 38400

    ADDRESS = 0xfe
    CALLSIGN = 'RADSAT'
    
    # create the UART interface
    uart = UART(UART_ID, baudrate=T3_BAUDRATE, tx=Pin(TX_PIN), rx=Pin(RX_PIN))
    # create a TupperSatRadio object
    radio = TupperSatRadio(uart, ADDRESS, CALLSIGN)
    
    return radio

def chunk(string, n):
    """Break a string into chunks of length n."""
    return (string[i:i+n] for i in range(0, len(string), n))

def parse_time(time_str):
    """Parse a time string HHMMSS.SSS into a Time object."""
    
    Time = namedtuple('Time', 'hour minute second microsecond')

    # split out the second and sub-second times
    _hhmmss, _milliseconds = time_str.split('.')

    # compute the sub-second time in microseconds
    _us = int(_milliseconds) * 1000

    # compute the hours, minutes and seconds
    _hh, _mm, _ss = (int(x) for x in chunk(_hhmmss, 2))

    return Time(_hh, _mm, _ss, _us)


def fetch_raw_data():
    """
    Fetch the output from Housekeeping.py
    
    Parameters:
    -----------
    None
    
    Returns:
    --------
    temp_int: float
    temp_ext: float
    pressure: float
    latitude: float
    longitude: float
    altitude: float
    radiation: float
    """
    try:
        temp_int, temp_ext, press, GPS_data = housekeeping()
    except Exception as e:
        print(e)
        print("Failed at reading housekeeping")
        temp_int, temp_ext, press, GPS_data = None, None, None, None

    if temp_int is not None:
        int_temp = temp_int
    else:
        int_temp = None
        
    if temp_ext is not None:
        ext_temp = temp_ext
    else:
        ext_temp = None
        
    if press is not None:
        pressure = press
    else:
        pressure = None
        
    # extract data
    if GPS_data is not None:
        raw_sentence = GPS_data['sentence'][-1]
        latitude = round(float(GPS_data['latitude'][0]), 4)
        longitude = round(float(GPS_data['longitude'][0]), 4)
        altitude = round(float(GPS_data['altitude'][0]), 2)
        timestamp = GPS_data['timestamp']
        checksum = GPS_data['checksum'][0]
        hdop = round(float(GPS_data["hdop"][0]), 2) 
    else:
        raw_sentence = None
        latitude = None
        longitude = None
        altitude = None
        timestamp = None
        checksum = None
        hdop = None
        
    return int_temp, ext_temp, pressure, longitude, latitude, altitude, timestamp, checksum, hdop

def send_to_sd():
    """
    Take the CSV file from fetch_clean_data() and send it to the local SD
    file for storage.
    
    Parameters:
    -----------
    transfer_data: file
        CSV file of clean data
        
    Returns:
    --------
    None
    """
    
    return

def send_to_ground(radio, data, kind=str):
    """
    Take the CSV file from fetch_clean_data() and send it to the ground
    station.
    
    Parameters:
    -----------
    transfer_data: file
        CSV file of clean data
        
    Returns:
    --------
    None
    """
    if "House" in kind:
        
        t_int = data[0]
        t_ext = data[1]
        p = data[2]
        long = data[3]
        lat = data[4]
        alt = data[5]
        time_1 = data[6]
        hd = data[-1]
        
        print("Printing telemetry stuff")
        print(long)
        print(lat)
        
        radio.send_telemetry(
            hhmmss     = time_1,
            latitude   = lat,
            longitude  = long,
            hdop       = hd,
            altitude   = alt,
            t_internal = t_int,
            t_external = t_ext,
            pressure   = p
        )
        
    if "Rad" in kind:
        
        cps = counts/60
        
        time_1 = bytearray(data[0])
        count = bytearray(data[1])
        alt = bytearray(data[-1])
        
        rad_data = [bytearray(data[0]), bytearray(data[1]), bytearray(data[-1])]
        
        radio.send_data(rad_data)
        
    
    return

def comms():
    #Radiation.loop()
    pin_nums = [6, 14, 15, 4, 5, 0, 1]
    
    
    # initialise antenna
    radio = setup_antenna(pin_nums)
    
    
    #Exceptions = []
    
    count = 0
    
    while count < 30:
    
        try:
            int_temp, ext_temp, pressure, longitude, latitude, altitude, timestamp, checksum, hdop = fetch_raw_data()
        except Exception as e:
            print("Exception; {e}")
            # Exceptions.append(time.time(), e)
            #int_temp, ext_temp, pressure, longitude, latitude, altitude, timestamp, checksum, hdop = None, None, None, None, None, None, None, None, None
            #continue
        
        print("Before I send to ground:\n")
        print(f"Internal Temp: {int_temp}")
        print(f"External Temp: {ext_temp}")
        print(f"Pressure: {pressure} millibars")
        print(f"Longitude: {longitude}")
        print(f"Latitude: {latitude}")
        print(f"Altitude: {altitude}")
        print(f"Time: {timestamp}")
        print(f"Checksum: {checksum}")
        print(f"HDOP: {hdop}")
        
        # parse time to correct format for sending telemetry
        try:
            time_1 = parse_time(timestamp)
        except IndexError:
            time_1 = None
        except AttributeError as e:
            time_1 = None
            
        housekeeping_data = [int_temp, ext_temp, pressure, longitude, latitude, altitude, time_1, hdop] 
        
        #send_to_sd(housekeeping_data)
        
        send_to_ground(radio, housekeeping_data, "House")
        
        count +=1
        rad.value_reset()
        time.sleep(10)
    
    
    #radiation_data = [timestamp, counts, altitude]
    
    #send_to_ground(radio, radiation_data, "Rad")
    
    return

if __name__ == "__main__":
    comms()
 