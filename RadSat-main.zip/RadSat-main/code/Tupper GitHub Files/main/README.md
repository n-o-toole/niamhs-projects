The main.py file is the main file that runs on loop and calls the other .py files for data. The logic works as detailed below:

The file imports all other files needed to collect and transmit data.

A configure() file is set up to establish connection to the sensors and put the GPS into airborne mode. It returns the sensors variable that is called in Housekeeping.py and Comms.py

The main() function sets the pin numbers for the configure() function and establishes connection.
The main() function tries to establish connection to the SD card using init_sd() from Comms.py using a try/except logic loop
The main() function tries to establish connection to the radio in a try/except logic loop

The Timer module from machine is used to begin on-board timers for storing housekeeping and sending telemetry for HK packets 1 & 2 along with the Rad packet

The values for store_house, send_house1, send_house2 and send_rad are set to False.

The functions store(), send1(), send2() and send_rad() are established to be called to set the above values to True when called.

An init_house() and start_rad() function are created to initialise the sending of telemetry for HK and Rad data by setting 1 minute periodic timers and implementing a delay.
These functions use a callback mechanism to call the send2() and send_rad() functions when enabled
The SD card storage is set on a 10 second periodic timer to write to the SD card.

The telemetry is started using a Timer.ONE_SHOT parameter that sets the timers for each telem function to begin

Once the values of store_house, send_house1 etc are set to True, the functions for storing/sending data are activated and data storage/telemetry activates before setting the values back to False.

Once the radiation data is sent, the file resets the counts in that loop in the Radiation.py file. This is done here to avoid a missed telemetry packet leading to lost counts.
