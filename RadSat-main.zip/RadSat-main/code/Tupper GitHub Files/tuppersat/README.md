Folder containing the files required for connection to and usage of the tuppersat radio telemetry.
