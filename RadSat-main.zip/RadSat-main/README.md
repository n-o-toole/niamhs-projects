# RadSat
GitHub repo for TupperSat project.

Final Files used in the Project can be found in /code/Tupper GitHub files in their own folder with respective README.md files for each major file.

Separate branches were used in the course of the project and can be viewed if desired.

Contributors: Eris Dempsey, Niamh O Toole.
