The Radiation.py file operates under the following logic:
The file initialises and connects to the Radiation sensor. It establishes the Pico pins used for the trigger and reading the ADC values
The Radiation class initialises the PWM width used for the project to set the pulse width required to trigger the pin
The Radiation class establishes the adc_val_list list for storing ADC voltage readings when the trigger threshold is met. There is also a time_list for times the pin is triggered.
The Radiation loop counter and total radiation counter are established.
Connection to the SD card is established
The count_detected() function is defined to add a count when the trigger threshold is met and read the ADC value stored on the ADC pin
The trigger mechanism is set up for the interrupt using Pin.irq method which checks for a rising pin and runs the count_detected() function
A seperate thread is set up for the interrupt to be able to run constantly as a stream to be called for values during loops, but runs unobstructed to ensure no missed detections
A count_fetch() function is defined to call the interrupt to provide counts for the loop before communication with ground station. This also writes to the SD card.
A count_reset() function is created to reset the loop counts to 0.
