from machine import Pin, ADC
from picozero import pico_led
import random
import time

button = Pin(22, Pin.IN, Pin.PULL_DOWN)
counter = 0
adc_pin = Pin(26, Pin.IN)
adc = ADC(adc_pin)
global val_list
val_list = []
def button_pressed(pin):
    global val
    val = adc.read_u16()
    if val > 512:
        global counter
        counter += 1
        val_list.append((time.time(),val))
        print(val)



time_now = time.time()



button.irq(trigger = Pin.IRQ_RISING, handler = button_pressed)
while True:
    time.sleep(30)
    print(val_list)
    val_list = []

