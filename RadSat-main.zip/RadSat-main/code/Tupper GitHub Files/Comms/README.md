This folder contains the comms.py file used in the RadSat TupperSat project. The logic works as follows:

A setup_antenna() function establishes a connection to the radio antenna through the Pico pins and returns the radio as a variable.

A chunk() function breaks a string into chunks of length n.

A parse_time() function tries to establish a value for the time based off the GPS time. If no GPS time is provided, the time is replaced by the onboard time.localtime() measurement in other areas.

A get_default_time() function establishes a default time as a string if the parse_time() function cannot find a GPS time.

A fetch_raw_data() function fetches the output from the Housekeeping.py housekeeping() function and returns the values as variables.
This is implemented using try/except loops that return None values if no values can be found to prevent complete system failure in the event that sensors get disconnected

An init_sd() function establishes a connection to the SD card

A write_to_sd() function attempts to write to the SD card when called, if not it returns an error statement and continues

The send_to_ground() function takes the radio, data, timestamp and data kind variables and reads to check if the data is Radiation or HK then attempts to transmit to ground
and returns 99999 as values for data if no data is available. Radiation data is converted to bytes before transfer.

The comms() function takes all the above functions and compiles them to run when called, checking connection to each sensor and trying to read and then transmit the data to ground.
This is again done using try/except loops to ensure system survivability in the situation where connection to sensors is lost. the function returns HK data, Rad data and a timestamp to be called in main.py
