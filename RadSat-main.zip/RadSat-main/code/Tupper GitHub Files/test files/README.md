A group of files used in testing sensors/software through the course of the project.
