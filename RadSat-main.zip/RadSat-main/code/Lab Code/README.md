Code that was developed during the lab sessions in Weeks 3-5. These documents shall be used 
as a skeleton from which we can build out primary code blocks for the TupperSat. Please put your
initials in the file name OR put your name as a comment at the beginning of the script before imports.
